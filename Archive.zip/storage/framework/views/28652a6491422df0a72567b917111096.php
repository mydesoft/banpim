 <!--**********************************
            Content body end
        ***********************************-->
		
        <!--**********************************
            Footer start
        ***********************************-->
        <div class="footer">
            <div class="copyright">
               <p>Copyright © Developed by <a href="" target="_blank">BanPim</a> <?php  echo date('Y') ?></p>
            </div>
        </div>
        <!--**********************************
            Footer end
        ***********************************-->

		<!--**********************************
           Support ticket button start
        ***********************************-->
		
        <!--**********************************
           Support ticket button end
        ***********************************--><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/BanPim/resources/views/includes/footer.blade.php ENDPATH**/ ?>