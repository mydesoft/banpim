<?php $__env->startSection('content'); ?>
        
		<!--**********************************
            Content body start
        ***********************************-->
        <div class="content-body">
			<div class="container-fluid">
				<a href="/create-media" class="btn btn-sm btn-primary">Create</a>
				<div class="row mt-4">
					<div class="table-responsive">
						<table id="example" class="display table" style="min-width: 845px">
							<thead>
								<tr>
									<th>S/N</th>
									<th>Name</th>
									<th>Media</th>
									<th>Description</th>
									<th>Category</th>
									<th>Created</th>
									
								</tr>

							</thead>
							<tbody>
								<?php $__currentLoopData = $medias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $media): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<tr>
										<td><?php echo e($i + 1); ?></td>
										<td><?php echo e($media->name); ?></td>
										<td><img src="<?php echo e(asset('storage/image/'.$media->image)); ?>" alt="" width="40"></td>
										<td><?php echo e($media->description); ?></td>
										<td><?php echo e($media->category->name); ?></td>
										<td><?php echo e($media->created_at); ?></td>
									</tr>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</tbody>
						</table>
					</div>
					
				</div>
			</div>
        </div>
		
 <?php $__env->stopSection(); ?>     


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/BanPim/resources/views/admin/media/media.blade.php ENDPATH**/ ?>