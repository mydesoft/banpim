<?php $__env->startSection('content'); ?>
        
		<!--**********************************
            Content body start
        ***********************************-->
        <div class="content-body">
			<div class="container-fluid">
				
				<div class="row">
					<div class="card">
                        <div class="card-title">
                            <h4 class="mt-4">Create Category</h4>
                        </div>
                        <div class="card-body">
                            <div class="col-md-8 offset-md-2">
                                <form method="POST" action="/create-category">
                                    <?php echo csrf_field(); ?>
                                    <div class="mb-3">
                                        <label><strong>Name</strong></label>
                                        <input type="text" class="form-control" name="name">
                                        <?php if($errors->has('name')): ?>
                                            <span class="text-danger text-small" role="alert">
                                                <?php echo e($errors->first('name')); ?>

                                            </span>
                                        <?php endif; ?>
                                    </div>
        
                                   
                                    
                                    <div class="text-center">
                                        <button type="submit" class="btn btn-primary btn-block">Create</button>
                                    </div>
                                </form>
                            </div>

                        </div>
                    </div>
				</div>
			</div>
        </div>
		
 <?php $__env->stopSection(); ?>     


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/BanPim/resources/views/admin/category/create-category.blade.php ENDPATH**/ ?>