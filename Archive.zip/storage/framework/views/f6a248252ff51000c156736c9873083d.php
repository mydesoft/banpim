<?php $__env->startSection('content'); ?>
        
		<!--**********************************
            Content body start
        ***********************************-->
        <div class="content-body">
			<div class="container-fluid">
				<a href="/create-category" class="btn btn-sm btn-primary">Create</a>
				<div class="row mt-4">
					<div class="table-responsive">
						<table id="example" class="display table" style="min-width: 845px">
							<thead>
								<tr>
									<th>Name</th>
									<th>Slug</th>
									<th>No of Products</th>
									<th>Created</th>
									
								</tr>

							</thead>
							<tbody>
								<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<tr>
										<td><?php echo e($category->name); ?></td>
										<td><?php echo e($category->slug); ?></td>
										<td><?php echo e($category->products->count()); ?></td>
										<td><?php echo e($category->created_at); ?></td>
									</tr>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</tbody>
						</table>
					</div>
					
				</div>
			</div>
        </div>
		
 <?php $__env->stopSection(); ?>     


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/BanPim/resources/views/admin/category/category.blade.php ENDPATH**/ ?>