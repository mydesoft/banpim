<?php $__env->startSection('content'); ?>
        
		<!--**********************************
            Content body start
        ***********************************-->
        <div class="content-body">
			<div class="container-fluid">
				
				<div class="row">
					<div class="card">
                        <div class="card-title">
                            <h4 class="mt-4">Create Media</h4>
                            
                        </div>
                        
                        <div class="card-body">
                            <center>

                                <small class="text-danger text-center">Kindly create a category before you create a product</small>
                            </center>
                        </div>
                            <div class="col-md-8 offset-md-2">
                                <form method="POST" action="/create-media" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <div class="mb-3">
                                        <label><strong>Name</strong></label>
                                        <input type="text" class="form-control" name="name">
                                        <?php if($errors->has('name')): ?>
                                            <span class="text-danger text-small" role="alert">
                                                <?php echo e($errors->first('name')); ?>

                                            </span>
                                        <?php endif; ?>
                                    </div>

                                    <div class="mb-3">
                                        <label><strong>Media</strong></label>
                                        <input type="file" class="form-control" name="image">
                                        <?php if($errors->has('image')): ?>
                                            <span class="text-danger text-small" role="alert">
                                                <?php echo e($errors->first('image')); ?>

                                            </span>
                                        <?php endif; ?>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label><strong>Category</strong></label>

                                       <select name="category_id" class="form-control">
                                        <option value="">Select category</option>
                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                       </select>
                                        <?php if($errors->has('category_id')): ?>
                                            <span class="text-danger text-small" role="alert">
                                                <?php echo e($errors->first('category_id')); ?>

                                            </span>
                                        <?php endif; ?>
                                    </div>
                                  

                                    <div class="mb-3">
                                        <label><strong>Description</strong></label>
                                        <textarea type="text" class="form-control" name="description" rows="10"></textarea>
                                        <?php if($errors->has('description')): ?>
                                            <span class="text-danger text-small" role="alert">
                                                <?php echo e($errors->first('description')); ?>

                                            </span>
                                        <?php endif; ?>
                                    </div>
                                    
                                    
                                    <div class="text-center">
                                        <button type="submit" class="btn btn-primary btn-block">Create</button>
                                    </div>
                                </form>
                            </div>

                        </div>
                    </div>
				</div>
			</div>
        </div>
		
 <?php $__env->stopSection(); ?>     


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/BanPim/resources/views/admin/media/create-media.blade.php ENDPATH**/ ?>