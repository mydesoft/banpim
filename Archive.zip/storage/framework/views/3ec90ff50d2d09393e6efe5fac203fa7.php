<?php $__env->startSection('content'); ?>
        
		<!--**********************************
            Content body start
        ***********************************-->
        <div class="content-body">
			<div class="container-fluid">
				
				<div class="row">
					<div class="card">
                        <div class="card-title">
                            <h4 class="mt-4">Create Produts</h4>
                            <center>

                                <small class="text-danger text-center">Kindly create a category before you create a product</small>
                            </center>
                        </div>
                        <div class="card-body">
                            <div class="col-md-8 offset-md-2">
                                <form method="POST" action="/create-product">
                                    <?php echo csrf_field(); ?>
                                    <div class="mb-3">
                                        <label><strong>Name</strong></label>
                                        <input type="text" class="form-control" name="name">
                                        <?php if($errors->has('name')): ?>
                                            <span class="text-danger text-small" role="alert">
                                                <?php echo e($errors->first('name')); ?>

                                            </span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="mb-3">
                                        <label><strong>Title</strong></label>
                                        <input type="text" class="form-control" name="title">
                                        <?php if($errors->has('title')): ?>
                                            <span class="text-danger text-small" role="alert">
                                                <?php echo e($errors->first('title')); ?>

                                            </span>
                                        <?php endif; ?>
                                    </div>
                        

                                    <div class="mb-3">
                                        <label><strong>Tag</strong></label>
                                        <input type="text" class="form-control" name="tag">
                                        <?php if($errors->has('tag')): ?>
                                            <span class="text-danger text-small" role="alert">
                                                <?php echo e($errors->first('tag')); ?>

                                            </span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="mb-3">
                                        <label><strong>Category</strong></label>

                                       <select name="category_id" class="form-control">
                                        <option value="">Select category</option>
                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                       </select>
                                        <?php if($errors->has('category_id')): ?>
                                            <span class="text-danger text-small" role="alert">
                                                <?php echo e($errors->first('category_id')); ?>

                                            </span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="mb-3">
                                        <label><strong>Size</strong></label>
                                        <input type="text" class="form-control" name="size">
                                        <?php if($errors->has('size')): ?>
                                            <span class="text-danger text-small" role="alert">
                                                <?php echo e($errors->first('size')); ?>

                                            </span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="mb-3">
                                        <label><strong>Weight</strong></label>
                                        <input type="text" class="form-control" name="weight">
                                        <?php if($errors->has('weight')): ?>
                                            <span class="text-danger text-small" role="alert">
                                                <?php echo e($errors->first('weight')); ?>

                                            </span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="mb-3">
                                        <label><strong>Sku</strong></label>
                                        <input type="text" class="form-control" name="sku">
                                        <?php if($errors->has('sku')): ?>
                                            <span class="text-danger text-small" role="alert">
                                                <?php echo e($errors->first('sku')); ?>

                                            </span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="mb-3">
                                        <label><strong>Colour</strong></label>
                                        <input type="text" class="form-control" name="colour">
                                        <?php if($errors->has('colour')): ?>
                                            <span class="text-danger text-small" role="alert">
                                                <?php echo e($errors->first('colour')); ?>

                                            </span>
                                        <?php endif; ?>
                                    </div>

                                    <div class="mb-3">
                                        <label><strong>Description</strong></label>
                                        <textarea type="text" class="form-control" name="description" rows="10"></textarea>
                                        <?php if($errors->has('description')): ?>
                                            <span class="text-danger text-small" role="alert">
                                                <?php echo e($errors->first('description')); ?>

                                            </span>
                                        <?php endif; ?>
                                    </div>
                                    
                                    
                                    <div class="text-center">
                                        <button type="submit" class="btn btn-primary btn-block">Create</button>
                                    </div>
                                </form>
                            </div>

                        </div>
                    </div>
				</div>
			</div>
        </div>
		
 <?php $__env->stopSection(); ?>     


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/BanPim/resources/views/admin/product/create-product.blade.php ENDPATH**/ ?>